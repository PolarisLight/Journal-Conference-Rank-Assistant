# AMO source submission for version 0.11.0

This archive contains the human-readable source and data inputs needed to
reproduce the unpacked Firefox extension submitted to AMO.

## Build environment

The supported reviewer environment is:

- Ubuntu 24.04.4 LTS (ARM64 or x86-64)
- Node.js 24.14.0
- Python 3.12.x
- No npm, pip, network download, package manager, or third-party dependency is required.

Node.js may be installed from https://nodejs.org/ or the distribution package
manager. Python 3.12 is included with Ubuntu 24.04.

## Build

From the root of this source archive, run:

```sh
bash build.sh
```

The script performs all required steps:

1. Copies the readable JavaScript, HTML, CSS, manifest, and image assets.
2. Encrypts the 28 plaintext journal/conference data shards with AES-GCM, including the Unicode shard used for Chinese titles.
3. Uses the original public IV values recorded in `source-data/encryption-ivs.json`
   so the generated data files are byte-for-byte identical to the AMO upload.
4. Verifies the SHA-256 digest of every unpacked file against
   `source-data/expected-files.json`; the build fails if any file differs.
5. Creates `dist/firefox-extension-v0.11.0.zip` using Python's standard library.

The verified unpacked extension is written to:

```text
dist/firefox-extension/
```

Reviewers should compare that directory with the unpacked AMO submission. ZIP
container metadata and compression may differ, while every contained file is
verified byte-for-byte by the build script.

## Windows convenience command

Windows is not required for review, but the equivalent local command is:

```powershell
.\build.ps1
```

## Source layout

- `source/`: readable extension code and static assets.
- `source-data/`: plaintext data shards, original public AES-GCM IVs, and
  expected file hashes.
- `scripts/build-extension.mjs`: data generation and byte verification.
- `scripts/package-extension.py`: deterministic ZIP packaging.

The extension's JavaScript, HTML, and CSS are not transpiled, concatenated,
minified, bundled, or obfuscated. Only the non-executable journal/conference
data shards are generated. The database cannot alter extension control flow and
contains no executable JavaScript or WebAssembly.

No private update-signing key is included or required. The public verification
key shipped with the extension is a static source asset.
