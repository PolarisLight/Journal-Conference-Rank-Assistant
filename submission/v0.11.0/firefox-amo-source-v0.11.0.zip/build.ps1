$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
node scripts/build-extension.mjs
python scripts/package-extension.py
