#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { createHash, webcrypto } from "node:crypto";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const sourceDir = path.join(root, "source");
const sourceDataDir = path.join(root, "source-data");
const outputDir = path.join(root, "dist", "firefox-extension");
const ivs = JSON.parse(fs.readFileSync(path.join(sourceDataDir, "encryption-ivs.json"), "utf8"));
const expected = JSON.parse(fs.readFileSync(path.join(sourceDataDir, "expected-files.json"), "utf8"));

fs.rmSync(path.join(root, "dist"), { recursive: true, force: true });
fs.cpSync(sourceDir, outputDir, { recursive: true });

const keyBytes = await webcrypto.subtle.digest(
  "SHA-256",
  new TextEncoder().encode("Journal Conference Rank Assistant packaged data v1"),
);
const key = await webcrypto.subtle.importKey("raw", keyBytes, "AES-GCM", false, ["encrypt"]);

for (const shard of Object.keys(ivs).sort()) {
  const sourceName = `catalog-shard-${shard}.private.json`;
  const outputName = `catalog-shard-${shard}.encrypted.json`;
  const plain = fs.readFileSync(path.join(sourceDataDir, sourceName));
  const iv = Buffer.from(ivs[shard], "base64");
  const [cipher, plainDigest] = await Promise.all([
    webcrypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plain),
    webcrypto.subtle.digest("SHA-256", plain),
  ]);
  const payload = {
    format: 1,
    keyMode: "packaged",
    iv: iv.toString("base64"),
    cipher: Buffer.from(cipher).toString("base64"),
    sha256: Buffer.from(plainDigest).toString("hex"),
  };
  fs.writeFileSync(path.join(outputDir, "extension", "data", outputName), JSON.stringify(payload));
}

function walk(dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const full = path.join(dir, entry.name);
    return entry.isDirectory() ? walk(full) : [full];
  });
}

const actual = {};
for (const file of walk(outputDir)) {
  const relative = path.relative(outputDir, file).split(path.sep).join("/");
  actual[relative] = createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

const differences = [];
for (const name of [...new Set([...Object.keys(expected), ...Object.keys(actual)])].sort()) {
  if (expected[name] !== actual[name]) {
    differences.push(`${name}: expected=${expected[name] ?? "missing"} actual=${actual[name] ?? "missing"}`);
  }
}
if (differences.length) {
  throw new Error(`Build differs from the submitted extension:\n${differences.join("\n")}`);
}

console.log(`Built and verified ${Object.keys(actual).length} files in ${outputDir}`);
