#!/usr/bin/env python3
"""Package the AMO source submission with portable POSIX entry names."""

import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = Path(sys.argv[1]).resolve()
INCLUDES = ("README.md", "build.sh", "build.ps1", "scripts", "source", "source-data")

files: list[Path] = []
for name in INCLUDES:
    item = ROOT / name
    if item.is_file():
        files.append(item)
    else:
        files.extend(path for path in item.rglob("*") if path.is_file())

OUTPUT.parent.mkdir(parents=True, exist_ok=True)
with ZipFile(OUTPUT, "w", ZIP_DEFLATED, compresslevel=9) as archive:
    for file in sorted(files):
        relative = file.relative_to(ROOT).as_posix()
        info = ZipInfo(relative, date_time=(2026, 7, 12, 0, 0, 0))
        info.compress_type = ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, file.read_bytes(), compress_type=ZIP_DEFLATED, compresslevel=9)

print(f"Created {OUTPUT} with {len(files)} portable entries")
