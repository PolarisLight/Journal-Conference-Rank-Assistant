#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
node scripts/build-extension.mjs
python3 scripts/package-extension.py
